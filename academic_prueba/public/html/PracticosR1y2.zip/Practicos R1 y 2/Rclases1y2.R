# setwd("~/Documentos/claseR/") #  poner lo que corresponda
# vector: colección de "cosas" de un mismo tipo (números enteros, "flotantes", letrasv <- )
num <- c(10,30,20,40)
num
let <- c("a","b","c","d")
let
forzado <- c(10,30,20,"a")
forzado
num[1]
num[1]+num[2]
forzado[1];forzado[2]
forzado[1]+forzado[2] # ¡ERROR!
# al mezclar números y letras (characters) pasaron todos a a ser "characters".
class(num)
class(let)
class(forzado)
numlet<- c(num,let)
numlet
is.matrix(let)
is.vector(let)
dospornum <- 2*num
dospornum
masuno <- dospornum +1
masuno
3*num # no lo estoy asignando a una variable, lo hago para ver, nomás. 
      # 3*num es un vector, aunque no tenga nombre
class(3*num) 
3*num[1] 
# esto puede interpretarse como 3 por el primer elemento de "num", 
3*(num[1])
# o como el primer elemento del vector 3*num, que no tiene nombre pero igual es un vector
(3*num)[1]

numlet
length(numlet)
numlet[3:5]
numlet[-1]
numlet[-c(1,3,5,7)]
numlet[5:8]
numlet[5:8][-2]
num1 <- c(10,30,20,40)
plot(num1)
plot(num1,pch=20,xlab="abcisas",ylab="ordenadas",col=3)
plot(num1, type="l",col="violet")
num2= c(24,15,25,24)
plot(num, type="l",col="violet")
par(new=TRUE)
plot(num2,type="l",col="blue")
#Nótese que hay algo mal con las escalas del eje Y. Y también con los nombres.

plot(num, type="l",col="violet",ylim=c(10,40),xlab="lo que sea",ylab="num1-2")
par(new=TRUE)
plot(num2,type="l",col="blue",ylim=c(10,40),xlab="",ylab="")
legend(1,40,legend=c("num1","num2"),text.col = c("violet","blue"),pch="/",col=c("violet","blue"))

# Ahora lo guardaré en un pdf
pdf("2rayas.pdf")
plot(num, type="l",col="violet",ylim=c(10,40),xlab="lo que sea",ylab="num1-2",
     main = "La línea fucsia y la línea azul")
par(new=TRUE)
plot(num2,type="l",col="blue",ylim=c(10,40),xlab="",ylab="")
legend(1,40,legend=c("num1","num2"),text.col = c("violet","blue"),pch="/",col=c("violet","blue"))
dev.off()
# del mismo modo se pueden hacer jpg, png, tiff, svg (dibujos vectoriales), etcétera.

barplot(num)
barplot(num,col="orange")
barplot(num,col=c(1,2,3,4)) # = c("black","red","green","blue")

barplot(num,col=c(1,2,3,4),names.arg = c("a","b","c","d"))
legend(0,40,c("A","B","C","D"),cex=0.5,text.col=c(1,2,3,4),bty="n")
legend(2.5,40,c("a","b","c","d"),cex=0.5,pch=20,col=c(1,2,3,4),bty="n")


num1=num
num2=c(23,2,45,34)

plot(num1,type="l",col=1,ylim=c(0,50),ylab="número")
par(new=TRUE)
plot(num2,type="l",col=2,ylim=c(0,50),
     axes = FALSE,ann =F )


# matriz: se la puede pensar como un vector estructurado en filas y columnas. 
n<-matrix(1:12,3,4)
# significa: "con el vector 1:12, hacer una matriz de 3 filas y cuatro columnas"
n<-matrix(1:12,3) # es lo mismo; el 4 lo deduce R.
n
letters
letters[1:12]
m <- matrix(letters[1:12],3)
m
# Puedo llamar a un elemento como si fuera parte del vector original
m[3] # elemento 3 del vector generador de la matriz m, o sea, de letters[1:12]
# Pero se suele hacer así:
m[3,1] # elemento de la fila 3 y la columna 1 de la matriz m
M<-matrix(letters[1:12],3,byrow = TRUE)
M
M[3] # aunque utilicé el vector distinto, M[3] sigue estando ubicado
# en el mismo lugar [3,1], por lo que su valor no es el mismo.



n
# recordemos qué era m
m
# Además de llamar a un elemento (m[3,4]) se puede llamar a una fila
m[3,]
# o a una columna
m[,3]
# y también usar el signo de menos como vimos en los vectores
m[-1,-1]

# Traten de descubrir qué pasa en los siguientes gráficos, recordando que n es
n
plot(n)
barplot(n)

mean(n)
colMeans(n)
rowMeans(n)
colnames(n)<-LETTERS[1:4]
rownames(n)<-letters[24:26]
n
# vamos a desordenarla
n<-matrix(sample(n),3)
colnames(n)<-LETTERS[1:4]
rownames(n)<-letters[24:26]
n

colnames(n)
max(n)
min(n)
sd(n)
barplot(n,col=c(7,3,9))

# existen comandos y paquetes específicos para realizar operaciones con 
# matrices según las reglas del álgebra matricial.
# si no, R las trata como a vectores
m1<-matrix(1:5,5)
m2<-matrix(1:5,1)
m1
m2
m1%*%m2

###############################

# data frame (marco de datos)
# lectura y escritura de archivos
# para dar una idea, se parece a una hoja de cálculo
# por lo general, es el resultado de importar una tabla desde afuera de R.
# vamos a correr unas líneas de código para crear un archivo de texto con una tabla

a<- LETTERS[1:5]
t1<- 101:1100
t2<- sample(letters,size = 1000,replace=TRUE)
t3<- sample(1:10000,size=1000)
t4<- sample(c("perro","gato","vaca","caballo","chancho"),size=1000,replace=TRUE,prob = c(1,2,3,4,5))
t5<-c()
for(i in 1:1000)
  t5[i] <- round(i+20*abs(rnorm(1)),2)

# acá ya haremos una data.frame, uniendo esos 5 vectores, que serán, cada uno, una columna
df1 <- data.frame(t1,t2,t3,t4,t5)
head(df1,25)
dim(df1)
colnames(df1)<-a
head(df1)
write.table(df1,file="tabla",col.names = TRUE,row.names = FALSE,quote=FALSE)
# corroboramos que existe el archivo
# ahora lo importamos (es absurdo, sí, pero es para aprender a a importar)

tabla <- read.table("tabla",header=TRUE)
head(tabla)
dim(tabla)
class(tabla)
attributes(tabla)
head(df1)
tabla$A
tabla[,1]
identical(tabla$A,tabla[,1])
colMeans(tabla[,c(1,3,5)])
hist(tabla$C)
cor(tabla$E,tabla$C)
aggregate(tabla$E,by=list(tabla$D),FUN="mean") # ¡ahora funciona!
tabmean <- aggregate(tabla$E,by=list(tabla$D),FUN="mean")
barplot(tabmean[,2],names.arg = tabmean[,1])
tablen <- aggregate(tabla$E,by=list(tabla$D),FUN="length") # como table, dice cuántos son de c/u
barplot(tablen[,2],names.arg = tablen[,1])
boxplot(tabla$E~tabla$D)
# en la dframe puede haber unas columnas de caracteres y 
# otras de números, cosa que no era posible en las matrices
table(tabla$D) # comparar con tablen
sort(table(tabla$D))
barplot(sort(table(tabla$D)),col=c("dark red","red","green","dark green","violet"))
# listas
# hay que pensarlas como un vector cuyos elementos pueden ser cualquier cosa: 
# vectores, números, letras, matrices, data frames y hasta listas.

ls()
lista <- list("a"=a,"b"=df1,"c"=dospornum,"d"=i,"e"=tabla)
length(lista)
lista[[1]]
sapply(lista,mean)
lista[[3]]

##########################################################
# gráficos
# instalar paquetes
# usar seqinr para algo
# uso de help (buscar un ejemplo claro)
# uso de grep en una tabla

# instalar paquetes 
# Aparte de los paquetes básicos (y sus respectivas funciones) 
# que se instalan automáticamente al instalar R, existen muchísimos otros
# con finalidades específicas. 
# veremos un ejemplo de cómo instalarl uno de ellos

install.packages("seqinr")
# nótese que aquí el nombre del paquete va entrecomillado
# espero las instrucciones que me da el programa, respondo "sí" cuando me pregunte algo,
# y listo. El proceso no es exactamente igual si estamos instalando usando el menú
# de rstudio.
# esos paquetes deben ser "llamados" en cada sesión de R en que los voy a usar.
library(seqinr) 
# ahora que el paquete está instalado, su nombre va sin comillas.
getwd()
g<-read.fasta("gordonia.nuc")
class(g)
class(g[[1]])
length(g)
g[[2]]
length(g[[2]])
lar=c()
for(i in 1:length(g)){
  lar[i]=length(g[[i]])
}

largos<-sapply(g,length)
gc<-sapply(g,GC)
hist(gc,100)
hist(largos,100)
names(largos)=c()
boxplot(largos,outline = FALSE)
pep <- lapply(g,translate)
length(pep)
a()

countAA <- list()
?count
#si no le digo "as.vector" el comando count me devuelve tables en vez de vectores
# ahora pasaré esto a data.frame, corrigiendo ciertos nombres horribles que aparecen automáticamente en el proceso
countAA[[1]]
class(countAA)
df1 <- as.data.frame(countAA)
dim(df1)
head(df1)
rownames(df1)<-a()[-1]

df <- t(df1)
dim(df)
head(df)
rownames(df)<-names(pep)
head(df)
boxplot(df,outline=FALSE)

#guardar grafico en pdf

pdf("grafAA.pdf")
boxplot(df,outline=FALSE)
dev.off()



# verlo con Zoom para ver todos los nombres de aminoácidos
################################# clase 2 ##################################

# sapply funciona como un loop sobre una lista, cuando tengo una función para aplicar.
lista=list(c(1,2,3),c(10,20,30),c(100,200,300))
lista
un_vector = sapply(lista,mean)
un_vector
summary(c(1,2,3))
una_matriz = sapply(lista,summary)
una_matriz
#más claro, la traspongo
otra_matriz = t(sapply(lista,summary))
otra_matriz
# funciones
# son "scripts dentro de los scripts", o fragmentos de código reutilizables, a los que se les dan
# algunos parámetros
# ejemplo: calcular el GC1,GC2 y GC3 de una secuencia

GC123 = function(seq){
  # cosas
  gc1=GC1(seq)
  gc2=GC2(seq)
  gc3=GC3(seq)
  vecGC=c(gc1,gc2,gc3)
  
  return(vecGC)
}
GC123
save(GC123,file="~/RRR/funciones/GC123.RData")
# ahora que la tengo escrita, puedo "correrla" una vez para que me quede incorporada a la sesión, pero
# normalmente ya la tendría guardada, y lo que hago es cargarla en la sesión.
load("~/RRR/funciones/GC123.RData")
# Ahora invento una secuencia y corro la función
secuencia=sample(s2c("ATGC"),1e4,replace=T) # 1e4 = 1 * 10⁴ = 10000
GC123(secuencia)

# Yo podría adaptar esta función para que, a partir de una lista de secuencias (un "fasta", pero en R)
# me calcule el GC de todas, y me lo devuelva como lista. Una forma es cambiarle el código, otra es crear
# otra función que utilice la primera iterativamente.

GC123lista <- function(lista_de_seqs){
  matrizdeGC<-sapply(lista_de_seqs,GC123)
  rownames(matrizdeGC)=c("gc1","gc2","gc3")
  return(t(matrizdeGC)) # la traspongo para que sea más fácil de entender
}

seq1 = sample(s2c("ATGC"),1e5,replace=T)
seq2 = sample(s2c("ATGC"),1e5,replace=T,prob = c(20,20,30,30))
seq3 = sample(s2c("ATGC"),1e5,replace=T,prob = c(30,30,20,20))
listaseqs123=list("sec1"=seq1,"sec2"=seq2,"sec3"=seq3)
#Ahora uso la función con esta lista, o con cualquiera
GC123lista(listaseqs123)
# la guardo
MGC=GC123lista(listaseqs123)
MGC
# redondeo los valores hasta una cifra más legible
round(MGC,3)
# Ahora veremos una función más compleja

load("mksplit.RData")
install.packages("SimRAD")
library(SimRAD)

# averiguar cómo usar la función sim.DNAseq, usando el help de R.
# probar generar una secuencia de 100 bases con un GC= 0.456. Guardarla en un objeto llamado simdna.
# con la función GC de seqinr (para lo cual tienen que hacer library(seqinr)) ver qué tal funcionó
# les va a dar un mensaje de error. Léanlo y miren la secuencia, a ver si se dan cuenta de qué hay que cambiar.
# buscar en el help las funciones s2c y c2s. 
# Usar la apropiada para modificar simdna para que pueda usarse como input de la función GC.


simdna=sim.DNAseq(10000,0.456)
library(seqinr)
vecdna=s2c(simdna)
GC(vecdna)
table(vecdna)

# Esta es, simplemente, otra forma de generar secuencias. En este caso quedan como una string, pero la
# pasé a vector con s3c (string to c; recordemos que c es el comando para crear un vector).
# si precisara hacer lo contrario, hago c2s. Ambas son funciones del paquete seqinr, por lo que si no
# hicimos antes library(seqinr) nos va a decir que no encuentra esa función.
# SI NO PUDIMOS INSTALAR SimRAD, hacemos lo siguiente con sample, 
# variando prob en cada caso, pero es bastante más complicado de código.


# Ahora vamos a crear un pequeño "cromosoma" de 11000 bp, que tenga un contenido GC que varíe
# a lo largo de la secuencia, por ejemplo, cada 550 bases (dentro de las cuales se mantiene
# bastante uniforme).


randomGC = runif(20)
# runif son números al azar entre 0 y 1 con distribución uniforme
summary(randomGC)
listaSubSeqs = list()
for(i in 1:20){
  listaSubSeqs[[i]] = s2c(sim.DNAseq(550,randomGC[i]))
}
chr = unlist(listaSubSeqs)
GC(chr)
length(chr)


# Ahora haremos ventanas de 100 bases para ver cómo varía el GC a lo largo de chr

load("mksplit.RData")
lista100 = mksplit(chr,100) # hace ventanas de 100 bases, con lo que quedarán 110 ventanas.
length(lista100)
vectorGC = sapply(lista100,GC)
plot(vectorGC,type="l",xlab="Cromosoma",ylab="GC level")

# Dividir un cromosoma en ventanas (generalmente de varias decenas de miles de bases cada una)
# es muy útil para ver cómo se distibuye cualquier variable (GC, cantidad de genes, determinados 
# secuencias breves (oligonucleótidos), o lo que sea, y cómo se correlacionan unas con otras).

# Vamos a ver qué hace la función mksplit
View(mksplit)
# usaremos la función split
# dicha función requiere un vector, y un factor
# Ej: si el vector es 1:20 y lo quiero dividir en 4 partes de 5, el factor será
fact = as.factor(c(1,1,1,1,1,2,2,2,2,2,3,3,3,3,3,4,4,4,4,4))
split(1:20,fact) # perfecto
split(1:23,fact) 
# como 1:23 es más largo que el factor, los empieza a pegar al primer fragmento.
split(1:30,fact) 
# ahí ya pegó en el segundo. Evidentemente, no me sirve que el vector (el chr) sea más largo.
split(1:17,fact) 
# Acá es más corto el "cromosoma" que el factor. No hay tanto problema, la última ventana queda corta.
# Yo quiero que no sea tan "bruto", o sea, que si le doy un tamaño de ventana de 10000 y me sobran unas bases
# al final (hasta 4999) las junte con la ventana anterior, que quedará hasta 50% más larga que las otras,
# y si me sobra más que eso, haga una ventana nueva, que nunca será más corta que lamitad de las otras.
# mksplit usa split, pero se encarga de que se cumpla todo eso con respecto a la última ventana.
# A eso se dedica el resto del código; pueden tratar de ver qué se entiende.
miniseq=rep("A",51) # probar después con 50 o menos
seq=c(chr,miniseq)
wsize=100
len <- length(seq)
nw <- round(len/wsize)
preLenFAC <- nw*wsize

lista <-list()
for (i in 1:nw){
  lista[[i]] <- c(rep(i,wsize))
}
lista
FAC <- unlist(lista)

if(preLenFAC<len){  # esto ocurre cuando sobra menos de media ventana (en este caso, si miniseq <=50)
  dif<- len-preLenFAC
  num <- lista[[nw]][1]
  suf <- rep(num,dif)
  FAC <- c(FAC,suf) # estiré el FAC (su última "ventana") hasta llegar al largo de seq
  llw <- wsize+dif
  pasoporaca <- "menor"
  
}else{              # o sea, cuando sobra media o más de media ventana
  dif <- preLenFAC-len
  FAC <- FAC[1:len] # rebané el FAC hasta igualar el largo de seq
  llw <- wsize-dif
  pasoporaca <- "else"
}
FAC <- as.factor(FAC)
sp <- split(seq,FAC)
writeLines(paste("Length of last window: ", llw))

pdf("cococho.pdf")
plot(sapply(lista100,GC),type="l",xlab="cromosoma trucho, ventanas de 100 bp",ylab="GC")
dev.off()

# también se puede guardar en formatos como png, jpg, tiff, etcétera. Cada uno tiene sus parámetros;
# por ejemplo, podría darle forma (en pulgadas) a la hoja del pdf, si ello fuera conveniente.
pdf("cococho_ancho.pdf",width = 14,height = 8)
plot(sapply(lista100,GC),type="l",xlab="cromosoma trucho, ventanas de 100 bp",ylab="GC")
dev.off()

Imaginemos estas dos variables (que podrían ser el gc y la cantidad de genes por ventana de un cromosoma)
a=c(0.23,0.24,0.16,0.22,0.25,0.28,0.35,0.38,0.43,0.36,0.38,0.47,0.44,0.38,0.45,0.47,0.39)
b=c(34,45,42,23,35,46,67,75,58,79,75,100,102,87,106,99,50)
pdf("dos_plots_en_uno.pdf",12,6)
plot(a,type="l",col="red")
par(new=TRUE) # esto hace que lo siguiente se dibuje en el mismo plot
plot(b,type="l",col="green",axes=FALSE,ann=FALSE)
dev.off()
# Hay maneras de crear un nuevo eje para la variable b, a la derecha, o de asegurarse que ambos gráficos usan
# la misma escala cuando son cosas comparables, pero dejémosla por aquí.

# Si quisiera poner ambos plots en una hoja pero separados, podría hacerlo así:
pdf("dos_plots_en_una_hoja.pdf",12,12)
par(mfrow=c(2,1)) # dos filas, una columna (de gráficos)
plot(a,type="l",col="red")
plot(b,type="l",col="green")
dev.off()

# Y si quiero un pdf de varias hojas (para pasarlo tipo presentación):
pdf("un_plot_por_hoja.pdf",12,12)
plot(a,type="l",col="red")
plot(b,type="l",col="green")
dev.off()


###################### encuestas ###### otro ejemplo de función ##########################
# ¿Qué tan "segura" es una encuesta?
# imaginemos que tenemos los resultados de una elección
a=850000
b=800000
o=350000
a+b+o
# y se dice que una encuesta que dio ganador a "b" estuvo mal hecha
# veamos si es así
P=c(rep("a",850000),rep("b",800000),rep("o",350000))
table(P)
head(P,10);tail(P,10)
# paso innecesario:
P=sample(P)
head(P,10);tail(P,10)
#repetimos varias veces el siguiente comando
table(sample(P,1000))
# ¿cómo cuantificar cuántas veces la encuesta dio ganador a "b"?
# hago un loop
sim=list()
for(i in 1:1000){
  sim[[i]]= table(sample(P,1000))
}
resultados=c()
for(i in 1:1000){
  resultados[i]=sim[[i]][1]>sim[[i]][2]
}
table(resultados)

# ¿Cómo simplificar el uso de este código?
# primero lo guardo en una función

encuestas=function(a,b,c,n){
  # a, b y c son votos de tres partidos, 
  # ordenados de mayor a menor
  # n es el tamaño de la muestra 
  P=c(rep("a",a),rep("b",b),rep("o",o))
  sim=list()
  for(i in 1:1000){
    sim[[i]]= table(sample(P,n))
  }
  resultados=c()
  for(i in 1:1000){
    resultados[i]=sim[[i]][1]>sim[[i]][2]
  }
  out=100*table(resultados)/sum(table(resultados))
  return(out)
}

# Normalmente, las funciones se guardan en una carpeta cualquiera
# que uno haya previamente destinado a esto. Por ejemplo:
# save(encuestas,file="~/RRR/funciones/encuestas.RData")
# y después, cuando abrís una sesión en la que las vas a usar,
# las tenés que cargar. En este caso:
# load("~/RRR/funciones/encuestas.RData")

encuestas(860000,840000,400000,1000)

f=function(n){
  return(n+1)
}